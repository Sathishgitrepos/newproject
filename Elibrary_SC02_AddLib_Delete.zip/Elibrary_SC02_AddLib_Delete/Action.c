Action()
{
	
		int TT=10,rc;
	web_cleanup_cookies();
	web_cache_cleanup();

	web_set_sockets_option("SSL_VERSION", "AUTO");


	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");
	
	
	web_reg_find("Search=Body",
		"SaveCount=TextCheck",
		"Text=Admin",
		LAST);
	
	lr_start_transaction("Elibrary_SC02_AddLib_Delete_T01_Launch");


	web_url("index.html", 
		"URL=http://{p_url}/index.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_cookie("ADRUM_BTa=R:0|g:05c86777-8343-42b0-bbee-874ebde9c158|n:icecream202008260436234_074d3225-7cdb-4130-830e-3b839fdcec84; DOMAIN=localhost");

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Fetch-Dest", 
		"style");

	web_concurrent_start(NULL);

	web_url("bootstrap.min.css", 
		"URL=http://{p_url}/bootstrap.min.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=http://{p_url}/index.html", 
		"Snapshot=t3.inf", 
		LAST);

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Fetch-Dest", 
		"script");

	web_url("jquery.min.js", 
		"URL=http://{p_url}/jquery.min.js", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=http://{p_url}/index.html", 
		"Snapshot=t4.inf", 
		LAST);

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Fetch-Dest", 
		"script");

	web_url("bootstrap.min.js", 
		"URL=http://{p_url}/bootstrap.min.js", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=http://{p_url}/index.html", 
		"Snapshot=t5.inf", 
		LAST);

	web_concurrent_end(NULL);
	
	if(atoi(lr_eval_string("{TextCheck}")) > 0)
	{
		lr_output_message("Elibrary_SC02_AddLib_Delete_T01_Launch is successfull");
			lr_end_transaction("Elibrary_SC02_AddLib_Delete_T01_Launch",LR_AUTO);
	}
	else
	{
		lr_error_message("Elibrary_SC02_AddLib_Delete_T01_Launch is failed for Iteration {P_Iteration},Host {P_Host}, Time {P_Time}");
		lr_end_transaction("Elibrary_SC02_AddLib_Delete_T01_Launch",LR_FAIL);
	}
	                
	lr_think_time(TT);




	/* launch completed */

	

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Origin", 
		"http://localhost:8082");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");
	
		web_reg_find("Search=Body",
		"SaveCount=TextCheck",
		"Text=Home",
		LAST);

lr_start_transaction("Elibrary_SC02_AddLib_Delete_T02_Login");

	web_submit_data("AdminLogin", 
		"Action=http://{p_url}/AdminLogin", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://{p_url}/index.html", 
		"Snapshot=t8.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=email", "Value={p_username}", ENDITEM, 
		"Name=password", "Value={p_password}", ENDITEM, 
		LAST);

//	web_add_cookie("ADRUM_BTa=R:41|g:0979e413-5fbc-4bf3-8a8d-ea255fb13d95|n:icecream202008260436234_074d3225-7cdb-4130-830e-3b839fdcec84; DOMAIN=localhost");
//
//	web_add_cookie("ADRUM_BT1=R:41|i:20742; DOMAIN=localhost");

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Fetch-Dest", 
		"image");

	web_concurrent_start(NULL);

	web_url("admin2.jpg", 
		"URL=http://{p_url}/images/admin2.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=http://{p_url}/AdminLogin", 
		"Snapshot=t9.inf", 
		LAST);

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Fetch-Dest", 
		"image");

	web_url("admin1.jpg", 
		"URL=http://{p_url}/images/admin1.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=http://{p_url}/AdminLogin", 
		"Snapshot=t10.inf", 
		LAST);

	web_concurrent_end(NULL);
	
	if(atoi(lr_eval_string("{TextCheck}")) > 0)
	{
		lr_output_message("Elibrary_SC02_AddLib_Delete_T02_Login is successfull");
			lr_end_transaction("Elibrary_SC02_AddLib_Delete_T02_Login",LR_AUTO);
	}
	else
	{
		lr_error_message("Elibrary_SC02_AddLib_Delete_T02_Login is failed for Iteration {P_Iteration},Host {P_Host}, Time {P_Time}");
		lr_end_transaction("Elibrary_SC02_AddLib_Delete_T02_Login",LR_FAIL);
	}
	                
	lr_think_time(TT);


	

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Dest", 
		"document");
	
	
	web_reg_find("Search=Body",
		"SaveCount=TextCheck",
		"Text=Add Librarian Form",
		LAST);

lr_start_transaction("Elibrary_SC02_AddLib_Delete_T03_AddLib");


	web_url("Add Librarian", 
		"URL=http://{p_url}/AddLibrarianForm", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{p_url}/AdminLogin", 
		"Snapshot=t11.inf", 
		"Mode=HTTP", 
		LAST);

	if(atoi(lr_eval_string("{TextCheck}")) > 0)
	{
		lr_output_message("Elibrary_SC02_AddLib_Delete_T03_AddLib is successfull");
			lr_end_transaction("Elibrary_SC02_AddLib_Delete_T03_AddLib",LR_AUTO);
	}
	else
	{
		lr_error_message("Elibrary_SC02_AddLib_Delete_T03_AddLib is failed for Iteration {P_Iteration},Host {P_Host}, Time {P_Time}");
		lr_end_transaction("Elibrary_SC02_AddLib_Delete_T03_AddLib",LR_FAIL);
	}
	                
	lr_think_time(TT);


	web_revert_auto_header("Sec-Fetch-User");

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Origin", 
		"http://localhost:8082");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");
	
	//Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9

	web_add_auto_header("Accept","text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9");
//Cache-Control: max-age=0
web_add_auto_header("Cache-Control:","max-age=0");

web_reg_find("Text=Librarian added successfully","SaveCount=TextCheck",
		LAST);

lr_start_transaction("Elibrary_SC02_AddLib_Delete_T04_ClkSubmit");

	web_submit_data("AddLibrarian", 
		"Action=http://{p_url}/AddLibrarian", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://{p_url}/AddLibrarianForm", 
		"Snapshot=t14.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=name", "Value={p_name}", ENDITEM, 
		"Name=email", "Value={p_emailid}", ENDITEM, 
		"Name=password", "Value={p_addlibpwd}", ENDITEM, 
		"Name=mobile", "Value={p_mobnumber}", ENDITEM, 
		LAST);
		
				if(atoi(lr_eval_string("{TextCheck}")) > 0)
	{
		lr_output_message("Elibrary_SC02_AddLib_Delete_T04_ClkSubmit is successfull");
			lr_end_transaction("Elibrary_SC02_AddLib_Delete_T04_ClkSubmit",LR_AUTO);
	}
	else
	{
		lr_error_message("Elibrary_SC02_AddLib_Delete_T04_ClkSubmit is failed for Iteration {P_Iteration},Host {P_Host}, Time {P_Time}");
		lr_end_transaction("Elibrary_SC02_AddLib_Delete_T04_ClkSubmit",LR_FAIL);
	}
	                
	lr_think_time(TT);

	
//	web_add_header("X-HTTP-Method-Override", 
//		"POST");
//
//	web_add_header("Sec-Fetch-Mode", 
//		"no-cors");
//
//	web_add_header("Sec-Fetch-Dest", 
//		"empty");
//
//	lr_think_time(16);
//
//	web_url("threatListUpdates_fetch", 
//		"URL=https://safebrowsing.googleapis.com/v4/threatListUpdates_fetch?$req="
//		"ChwKDGdvb2dsZWNocm9tZRIMODYuMC40MjQwLjc1GikIBRABGhsKDQgFEAYYASIDMDAxMAEQ07UJGgIYCJu-OMAiBCABIAIoARopCAEQARobCg0IARAGGAEiAzAwMTABEJv7BxoCGAhJag1hIgQgASACKAEaKQgDEAEaGwoNCAMQBhgBIgMwMDEwARCUhwgaAhgIWF78giIEIAEgAigBGikIBxABGhsKDQgHEAYYASIDMDAxMAEQ3KEIGgIYCOOKhikiBCABIAIoARonCAEQARoZCg0IARAGGAEiAzAwMTADEBQaAhgIseeQLSIEIAEgAigDGigIARAIGhoKDQgBEAgYASIDMDAxMAQQmBwaAhgIOOyV_yIEIAEgAigEGicICRABGhkKDQgJEAYYASIDMDAxMAYQAxoCGAh5ozZ0IgQgASACKAYaKAgPEAEaGgoNCA8QBhgBIgMwMDEwARDLRxoCGAj43FWbIgQgASACKAEaJwgKEAgaGQ"
//		"oNCAoQCBgBIgMwMDEwARAGGgIYCO0mYOUiBCABIAIoARonCAkQARoZCg0ICRAGGAEiAzAwMTABEB0aAhgIYpSc2yIEIAEgAigBGigICBABGhoKDQgIEAYYASIDMDAxMAEQhQoaAhgI-UnIIyIEIAEgAigBGigIDRABGhoKDQgNEAYYASIDMDAxMAEQkn0aAhgIBmCQ5iIEIAEgAigBGikIDhABGhsKDQgOEAYYASIDMDAxMAEQwrIEGgIYCFnLb-ciBCABIAIoARooCBAQARoaCg0IEBAGGAEiAzAwMTABEO8FGgIYCKr2PtgiBCABIAIoASICCAE=&$ct=application/x-protobuf&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw", 
//		"Resource=1", 
//		"RecContentType=application/x-protobuf", 
//		"Referer=", 
//		"Snapshot=t15.inf", 
//		LAST);
//
//	web_add_cookie("ADRUM_BTa=R:47|g:91ae1e73-6ce0-42a3-b805-c2a7bf9fff36|n:icecream202008260436234_074d3225-7cdb-4130-830e-3b839fdcec84; DOMAIN=localhost");
//
//	web_add_cookie("ADRUM_BT1=R:47|i:30408|e:55; DOMAIN=localhost");

	

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");
	
	//<tr><td>14</td><t'cd>ggfgf</td><td>
	web_reg_save_param("C_ID","LB=<tr><td>","RB=</td><td>{p_name}",LAST);
	
	web_reg_find("Search=Body",
		"SaveCount=TextCheck",
		"Text=Name",
		LAST);
	
	lr_start_transaction("Elibrary_SC02_AddLib_Delete_T05_ViewLib");

	web_url("View Librarian", 
		"URL=http://{p_url}/ViewLibrarian", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{p_url}/AddLibrarian", 
		"Snapshot=t16.inf", 
		"Mode=HTTP", 
		LAST);

//	web_add_cookie("ADRUM_BTa=R:44|g:2549375b-0534-4bce-97f3-78b3c9124035|n:icecream202008260436234_074d3225-7cdb-4130-830e-3b839fdcec84; DOMAIN=localhost");

		if(atoi(lr_eval_string("{TextCheck}")) > 0)
	{
		lr_output_message("Elibrary_SC02_AddLib_Delete_T05_ViewLib is successfull");
			lr_end_transaction("Elibrary_SC02_AddLib_Delete_T05_ViewLib",LR_AUTO);
	}
	else
	{
		lr_error_message("Elibrary_SC02_AddLib_Delete_T05_ViewLib is failed for Iteration {P_Iteration},Host {P_Host}, Time {P_Time}");
		lr_end_transaction("Elibrary_SC02_AddLib_Delete_T05_ViewLib",LR_FAIL);
	}
	                
	lr_think_time(TT);
	
	web_reg_find("Search=Body",
		"SaveCount=TextCheck",
		"Text=AddLibrarianForm\"",
		LAST);
	
	lr_start_transaction("Elibrary_SC02_AddLib_Delete_T06_ClkDelete");

	web_url("Delete", 
		"URL=http://{p_url}/DeleteLibrarian?id={C_ID}", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{p_url}/ViewLibrarian", 
		"Snapshot=t17.inf", 
		"Mode=HTTP", 
		LAST);
		if(atoi(lr_eval_string("{TextCheck}")) > 0)
	{
		lr_output_message("Elibrary_SC02_AddLib_Delete_T06_ClkDelete is successfull");
			lr_end_transaction("Elibrary_SC02_AddLib_Delete_T06_ClkDelete",LR_AUTO);
	}
	else
	{
		lr_error_message("Elibrary_SC02_AddLib_Delete_T06_ClkDelete is failed for Iteration {P_Iteration},Host {P_Host}, Time {P_Time}");
		lr_end_transaction("Elibrary_SC02_AddLib_Delete_T06_ClkDelete",LR_FAIL);
	}
	                
	lr_think_time(TT);


lr_start_transaction("Elibrary_SC02_AddLib_Delete_T07_Logout");

	web_url("Logout", 
		"URL=http://{p_url}/LogoutAdmin", 
		"Resource=0", 
		"Referer=http://{p_url}/ViewLibrarian", 
		"Snapshot=t18.inf", 
		"Mode=HTTP", 
		LAST);
	


	lr_end_transaction("Elibrary_SC02_AddLib_Delete_T07_Logout",LR_AUTO);
	lr_think_time(TT);

	return 0;
}