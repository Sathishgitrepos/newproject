Action()
{
	
	int TT=10,rc;
	web_cleanup_cookies();
	web_cache_cleanup();

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_header("Sec-Fetch-Site", 
		"none");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");
	
	
	web_reg_find("Search=Body",
		"SaveCount=TextCheck",
		"Text=Admin",
		LAST);
	
	lr_start_transaction("Elibrary_SC04_EditLibrarian_T01_Launch");


	web_url("index.html", 
		"URL=http://{p_url}/index.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTTP", 
		LAST);

//	web_add_cookie("ADRUM_BTa=R:0|g:e4a853e4-b3a7-494e-bc66-bcd05f7680b0|n:icecream202008260436234_074d3225-7cdb-4130-830e-3b839fdcec84; DOMAIN=localhost");

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Fetch-Dest", 
		"style");

	web_concurrent_start(NULL);

	web_url("bootstrap.min.css", 
		"URL=http://{p_url}/bootstrap.min.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=http://{p_url}/index.html", 
		"Snapshot=t2.inf", 
		LAST);

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Fetch-Dest", 
		"script");

	web_url("jquery.min.js", 
		"URL=http://{p_url}/jquery.min.js", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=http://{p_url}/index.html", 
		"Snapshot=t3.inf", 
		LAST);

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Fetch-Dest", 
		"script");

	web_url("bootstrap.min.js", 
		"URL=http://{p_url}/bootstrap.min.js", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=http://{p_url}/index.html", 
		"Snapshot=t4.inf", 
		LAST);

	web_concurrent_end(NULL);
	
	if(atoi(lr_eval_string("{TextCheck}")) > 0)
	{
		lr_output_message("Elibrary_SC04_EditLibrarian_T01_Launch is successfull");
			lr_end_transaction("Elibrary_SC04_EditLibrarian_T01_Launch",LR_AUTO);
	}
	else
	{
		lr_error_message("Elibrary_SC04_EditLibrarian_T01_Launch is failed for Iteration {P_Iteration},Host {P_Host}, Time {P_Time}");
		lr_end_transaction("Elibrary_SC04_EditLibrarian_T01_Launch",LR_FAIL);
	}
	                
	lr_think_time(TT);
	


	/* launch completed */



	web_add_header("Origin", 
		"http://localhost:8082");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");
	
		web_reg_find("Search=Body",
		"SaveCount=TextCheck",
		"Text=Home",
		LAST);
	
	lr_start_transaction("Elibrary_SC04_EditLibrarian_T02_Login");


	web_submit_data("AdminLogin", 
		"Action=http://{p_url}/AdminLogin", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://{p_url}/index.html", 
		"Snapshot=t8.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=email", "Value={p_username}", ENDITEM, 
		"Name=password", "Value={p_password}", ENDITEM, 
		LAST);

//	web_add_cookie("ADRUM_BTa=R:41|g:63c49ffc-5851-4caa-bcb1-80ac10afea25|n:icecream202008260436234_074d3225-7cdb-4130-830e-3b839fdcec84; DOMAIN=localhost");
//
//	web_add_cookie("ADRUM_BT1=R:41|i:20742; DOMAIN=localhost");

	web_concurrent_start(NULL);

	web_url("admin2.jpg", 
		"URL=http://{p_url}/images/admin2.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=http://{p_url}/AdminLogin", 
		"Snapshot=t9.inf", 
		LAST);

	web_url("admin1.jpg", 
		"URL=http://{p_url}/images/admin1.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=http://{p_url}/AdminLogin", 
		"Snapshot=t10.inf", 
		LAST);

	web_concurrent_end(NULL);
	
	if(atoi(lr_eval_string("{TextCheck}")) > 0)
	{
		lr_output_message("Elibrary_SC04_EditLibrarian_T02_Login is successfull");
			lr_end_transaction("Elibrary_SC04_EditLibrarian_T02_Login",LR_AUTO);
	}
	else
	{
		lr_error_message("Elibrary_SC04_EditLibrarian_T02_Login is failed for Iteration {P_Iteration},Host {P_Host}, Time {P_Time}");
		lr_end_transaction("Elibrary_SC04_EditLibrarian_T02_Login",LR_FAIL);
	}
	                
	lr_think_time(TT);

	
	//<tr><td>7</td><td>
//	web_reg_save_param("C_id","LB=<tr><td>","RB=</td><td>","ORD=ALL",LAST);
//	             



	web_reg_find("Search=Body",
		"SaveCount=TextCheck",
		"Text=Name",
		LAST);
	
	lr_start_transaction("Elibrary_SC04_EditLibrarian_T03_ClkViewLib");

	web_url("View Librarian", 
		"URL=http://{p_url}/ViewLibrarian", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{p_url}/AdminLogin", 
		"Snapshot=t11.inf", 
		"Mode=HTTP", 
		LAST);
	
	if(atoi(lr_eval_string("{TextCheck}")) > 0)
	{
		lr_output_message("Elibrary_SC04_EditLibrarian_T03_ClkViewLib is successfull");
			lr_end_transaction("Elibrary_SC04_EditLibrarian_T03_ClkViewLib",LR_AUTO);
	}
	else
	{
		lr_error_message("Elibrary_SC04_EditLibrarian_T03_ClkViewLib is failed for Iteration {P_Iteration},Host {P_Host}, Time {P_Time}");
		lr_end_transaction("Elibrary_SC04_EditLibrarian_T03_ClkViewLib",LR_FAIL);
	}
	                
	lr_think_time(TT);

	
	//<tr><td>7</td><td>ajayprem111</td><td>ajay@ff.com</td><td>fdfd</td><td>454545555</td><td><a href='E
//	web_reg_save_param("C_name","LB={C_id_{COUNT}}</td><td>","RB=</td><td>",LAST);
//	web_reg_save_param("C_name","LB={C_id_{COUNT}}</td><td>","RB=</td><td>",LAST);
	



	web_reg_find("Search=Body",
		"SaveCount=TextCheck",
		"Text=Edit Librarian Form",
		LAST);
	
		lr_start_transaction("Elibrary_SC04_EditLibrarian_T04_ClkEdit");

	web_url("Edit", 
		"URL=http://{p_url}/EditLibrarianForm?id={p_id}", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{p_url}/ViewLibrarian", 
		"Snapshot=t12.inf", 
		"Mode=HTTP", 
		LAST);
	
	if(atoi(lr_eval_string("{TextCheck}")) > 0)
	{
		lr_output_message("Elibrary_SC04_EditLibrarian_T04_ClkEdit is successfull");
			lr_end_transaction("Elibrary_SC04_EditLibrarian_T04_ClkEdit",LR_AUTO);
	}
	else
	{
		lr_error_message("Elibrary_SC04_EditLibrarian_T04_ClkEdit is failed for Iteration {P_Iteration},Host {P_Host}, Time {P_Time}");
		lr_end_transaction("Elibrary_SC04_EditLibrarian_T04_ClkEdit",LR_FAIL);
	}
	                
	lr_think_time(TT);
	
	
	web_revert_auto_header("Sec-Fetch-User");

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");


	web_add_header("Origin", 
		"http://localhost:8082");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");
	
	


	web_reg_find("Search=Body",
		"SaveCount=TextCheck",
		"Text=View Librarian",
		LAST);
	
	lr_start_transaction("Elibrary_SC04_EditLibrarian_T05_ClkUpdate");

	web_submit_data("EditLibrarian", 
		"Action=http://{p_url}/EditLibrarian", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://{p_url}/EditLibrarianForm?id={p_id}", 
		"Snapshot=t14.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=id", "Value={p_id}", ENDITEM, 
		"Name=name", "Value={P_NAME}", ENDITEM, 
		"Name=email", "Value={P_EMAILID}", ENDITEM, 
		"Name=password", "Value={P_PWD}", ENDITEM, 
		"Name=mobile", "Value={P_MOBPWD}{chng}", ENDITEM, 
		LAST);
	
	if(atoi(lr_eval_string("{TextCheck}")) > 0)
	{
		lr_output_message("Elibrary_SC04_EditLibrarian_T05_ClkUpdate is successfull");
			lr_end_transaction("Elibrary_SC04_EditLibrarian_T05_ClkUpdate",LR_AUTO);
	}
	else
	{
		lr_error_message("Elibrary_SC04_EditLibrarian_T05_ClkUpdate is failed for Iteration {P_Iteration},Host {P_Host}, Time {P_Time}");
		lr_end_transaction("Elibrary_SC04_EditLibrarian_T05_ClkUpdate",LR_FAIL);
	}
	                
	lr_think_time(TT);

	
	lr_start_transaction("Elibrary_SC04_EditLibrarian_T06_Logout");

	web_url("Logout", 
		"URL=http://{p_url}/LogoutAdmin", 
		"Resource=0", 
		"Referer=http://{p_url}/ViewLibrarian", 
		"Snapshot=t15.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("Elibrary_SC04_EditLibrarian_T06_Logout",LR_AUTO);
	lr_think_time(TT);

	return 0;
}