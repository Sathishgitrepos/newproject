Action()
{
	
	int TT=10,rc;
	web_cleanup_cookies();
	web_cache_cleanup();

	web_add_header("Sec-Fetch-Site", 
		"none");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");
	



	web_reg_find("Search=Body",
		"SaveCount=TextCheck",
		"Text=Admin",
		LAST);
	
		lr_start_transaction("Elib_SC01_LoginLogout_T01_Launch");

	web_url("index.html", 
		"URL=http://{p_url}", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTTP", 
		LAST);

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Fetch-Dest", 
		"script");

	web_concurrent_start(NULL);

	web_url("jquery.min.js", 
		"URL=http://localhost:8082/ELibrary/jquery.min.js", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=http://localhost:8082/ELibrary/index.html", 
		"Snapshot=t2.inf", 
		LAST);

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Fetch-Dest", 
		"style");

	web_url("bootstrap.min.css", 
		"URL=http://localhost:8082/ELibrary/bootstrap.min.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=http://localhost:8082/ELibrary/index.html", 
		"Snapshot=t3.inf", 
		LAST);

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Fetch-Dest", 
		"script");

	web_url("bootstrap.min.js", 
		"URL=http://localhost:8082/ELibrary/bootstrap.min.js", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=http://localhost:8082/ELibrary/index.html", 
		"Snapshot=t4.inf", 
		LAST);

	web_concurrent_end(NULL);
	
	
	if(atoi(lr_eval_string("{TextCheck}")) > 0)
	{
		lr_output_message("Elib_SC01_LoginLogout_T01_Launch is successfull");
			lr_end_transaction("Elib_SC01_LoginLogout_T01_Launch",LR_AUTO);
	}
	else
	{
		lr_error_message("Elib_SC01_LoginLogout_T01_Launch is failed for Iteration {P_Iteration},Host {P_Host}, Time {P_Time}");
		lr_end_transaction("Elib_SC01_LoginLogout_T01_Launch",LR_FAIL);
	}
	                
	lr_think_time(TT);

	



	/* launch completed */

	

	web_add_header("Origin", 
		"http://localhost:8082");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

//	lr_think_time(27);
	
	

	web_reg_find("Search=Body",
		"SaveCount=TextCheck",
		"Text=Home",
		LAST);
	
	lr_start_transaction("Elib_SC01_LoginLogout_T02_Login");

	web_submit_data("AdminLogin", 
		"Action=http://localhost:8082/ELibrary/AdminLogin", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://localhost:8082/ELibrary/index.html", 
		"Snapshot=t8.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=email", "Value={p_username}", ENDITEM, 
		"Name=password", "Value={p_password}", ENDITEM, 
		LAST);

	web_concurrent_start(NULL);

	web_url("admin2.jpg", 
		"URL=http://localhost:8082/ELibrary/images/admin2.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=http://localhost:8082/ELibrary/AdminLogin", 
		"Snapshot=t9.inf", 
		LAST);

	web_url("admin1.jpg", 
		"URL=http://localhost:8082/ELibrary/images/admin1.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=http://localhost:8082/ELibrary/AdminLogin", 
		"Snapshot=t10.inf", 
		LAST);

	web_concurrent_end(NULL);
	if(atoi(lr_eval_string("{TextCheck}")) > 0)
	{
		lr_output_message("Elib_SC01_LoginLogout_T02_Login is successfull");
			lr_end_transaction("Elib_SC01_LoginLogout_T02_Login",LR_AUTO);
	}
	else
	{
		lr_error_message("Elib_SC01_LoginLogout_T02_Login is failed for Iteration {P_Iteration},Host {P_Host}, Time {P_Time}");
		lr_end_transaction("Elib_SC01_LoginLogout_T02_Login",LR_FAIL);
	}
	                
	lr_think_time(TT);



	lr_start_transaction("Elib_SC01_LoginLogout_T03_Logout");

	web_url("Logout", 
		"URL=http://localhost:8082/ELibrary/LogoutAdmin", 
		"Resource=0", 
		"Referer=http://localhost:8082/ELibrary/AdminLogin", 
		"Snapshot=t11.inf", 
		"Mode=HTTP", 
		LAST);
	
	lr_end_transaction("Elib_SC01_LoginLogout_T03_Logout",LR_AUTO);
	lr_think_time(TT);
	
	       



	return 0;
}