Action()
{
	int TT=10,rc;
	web_cleanup_cookies();
	web_cache_cleanup();	

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_header("Sec-Fetch-Site", 
		"none");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");
	
	
	web_reg_find("Search=Body",
		"SaveCount=TextCheck",
		"Text=Admin",
		LAST);
	
	lr_start_transaction("Elibrary_SC03_ViewLibrarian_T01_Launch");


	web_url("index.html", 
		"URL=http://{p_url}/index.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTTP", 
		LAST);

//	web_add_cookie("ADRUM_BTa=R:0|g:4d66422b-17a5-4ac3-ac3b-b583f8184f17|n:icecream202008260436234_074d3225-7cdb-4130-830e-3b839fdcec84; DOMAIN=localhost");

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Fetch-Dest", 
		"style");

	web_concurrent_start(NULL);

	web_url("bootstrap.min.css", 
		"URL=http://{p_url}/bootstrap.min.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=http://{p_url}/index.html", 
		"Snapshot=t2.inf", 
		LAST);

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Fetch-Dest", 
		"script");

	web_url("jquery.min.js", 
		"URL=http://{p_url}/jquery.min.js", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=http://{p_url}/index.html", 
		"Snapshot=t3.inf", 
		LAST);

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Fetch-Dest", 
		"script");

	web_url("bootstrap.min.js", 
		"URL=http://{p_url}/bootstrap.min.js", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=http://{p_url}/index.html", 
		"Snapshot=t4.inf", 
		LAST);

	web_concurrent_end(NULL);
	
		if(atoi(lr_eval_string("{TextCheck}")) > 0)
	{
		lr_output_message("Elibrary_SC03_ViewLibrarian_T01_Launch is successfull");
			lr_end_transaction("Elibrary_SC03_ViewLibrarian_T01_Launch",LR_AUTO);
	}
	else
	{
		lr_error_message("Elibrary_SC03_ViewLibrarian_T01_Launch is failed for Iteration {P_Iteration},Host {P_Host}, Time {P_Time}");
		lr_end_transaction("Elibrary_SC03_ViewLibrarian_T01_Launch",LR_FAIL);
	}
	                
	lr_think_time(TT);
	
	web_add_header("Origin", 
		"http://localhost:8082");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

		web_reg_find("Search=Body",
		"SaveCount=TextCheck",
		"Text=Home",
		LAST);
	
lr_start_transaction("Elibrary_SC03_ViewLibrarian_T02_Login");

	web_submit_data("AdminLogin", 
		"Action=http://{p_url}/AdminLogin", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://{p_url}/index.html", 
		"Snapshot=t9.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=email", "Value={p_username}", ENDITEM, 
		"Name=password", "Value={p_password}", ENDITEM, 
		LAST);

//	web_add_cookie("ADRUM_BTa=R:41|g:3d361bc6-371f-4aa7-953b-a87df0ae6e64|n:icecream202008260436234_074d3225-7cdb-4130-830e-3b839fdcec84; DOMAIN=localhost");
//
//	web_add_cookie("ADRUM_BT1=R:41|i:20742; DOMAIN=localhost");
//
//	web_add_cookie("ADRUM_BTs=R:41|s:f; DOMAIN=localhost");

	web_concurrent_start(NULL);

	web_url("admin2.jpg", 
		"URL=http://{p_url}/images/admin2.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=http://{p_url}/AdminLogin", 
		"Snapshot=t10.inf", 
		LAST);

	web_url("admin1.jpg", 
		"URL=http://{p_url}/images/admin1.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=http://{p_url}/AdminLogin", 
		"Snapshot=t11.inf", 
		LAST);

	web_concurrent_end(NULL);
		if(atoi(lr_eval_string("{TextCheck}")) > 0)
	{
		lr_output_message("Elibrary_SC03_ViewLibrarian_T02_Login is successfull");
			lr_end_transaction("Elibrary_SC03_ViewLibrarian_T02_Login",LR_AUTO);
	}
	else
	{
		lr_error_message("Elibrary_SC03_ViewLibrarian_T02_Login is failed for Iteration {P_Iteration},Host {P_Host}, Time {P_Time}");
		lr_end_transaction("Elibrary_SC03_ViewLibrarian_T02_Login",LR_FAIL);
	}
	                
	lr_think_time(TT);

	web_reg_find("Search=Body",
		"SaveCount=TextCheck",
		"Text=Name",
		LAST);
	
	lr_start_transaction("Elibrary_SC03_ViewLibrarian_T03_ClkViewLibrarian");

	web_url("View Librarian", 
		"URL=http://{p_url}/ViewLibrarian", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{p_url}/AdminLogin", 
		"Snapshot=t12.inf", 
		"Mode=HTTP", 
		LAST);
	
	if(atoi(lr_eval_string("{TextCheck}")) > 0)
	{
		lr_output_message("Elibrary_SC03_ViewLibrarian_T03_ClkViewLibrarian is successfull");
			lr_end_transaction("Elibrary_SC03_ViewLibrarian_T03_ClkViewLibrarian",LR_AUTO);
	}
	else
	{
		lr_error_message("Elibrary_SC03_ViewLibrarian_T03_ClkViewLibrarian is failed for Iteration {P_Iteration},Host {P_Host}, Time {P_Time}");
		lr_end_transaction("Elibrary_SC03_ViewLibrarian_T03_ClkViewLibrarian",LR_FAIL);
	}
	                
	lr_think_time(TT);

	
	lr_start_transaction("Elibrary_SC03_ViewLibrarian_T04_Logout");

	web_url("Logout", 
		"URL=http://{p_url}/LogoutAdmin", 
		"Resource=0", 
		"Referer=http://{p_url}/ViewLibrarian", 
		"Snapshot=t13.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("Elibrary_SC03_ViewLibrarian_T04_Logout",LR_AUTO);
	lr_think_time(TT);

	return 0;
}