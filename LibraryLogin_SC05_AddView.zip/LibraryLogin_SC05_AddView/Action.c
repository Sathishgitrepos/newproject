Action()
{
	
	int TT=10,rc;
	web_cleanup_cookies();
	web_cache_cleanup();


	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_header("Sec-Fetch-Site", 
		"none");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");
	



	web_reg_find("Search=Body",
		"SaveCount=TextCheck",
		"Text=Librarian Login",
		LAST);
	
		lr_start_transaction("LibraryLogin_SC05_AddView_T01_launch");

	web_url("index.html", 
		"URL=http://{p_url}/index.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTTP", 
		LAST);

//	web_add_cookie("ADRUM_BTa=R:0|g:f208bffe-7c91-4571-ae5a-de5847baa725|n:icecream202008260436234_074d3225-7cdb-4130-830e-3b839fdcec84; DOMAIN=localhost");

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Fetch-Dest", 
		"style");
		
	

	web_url("bootstrap.min.css", 
		"URL=http://{p_url}/bootstrap.min.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=http://{p_url}/index.html", 
		"Snapshot=t2.inf", 
		LAST);

	

	web_add_auto_header("Sec-Fetch-Dest", 
		"script");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_url("jquery.min.js", 
		"URL=http://{p_url}/jquery.min.js", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=http://{p_url}/index.html", 
		"Snapshot=t4.inf", 
		LAST);

	web_url("bootstrap.min.js", 
		"URL=http://{p_url}/bootstrap.min.js", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=http://{p_url}/index.html", 
		"Snapshot=t5.inf", 
		LAST);

	

	
	
	if(atoi(lr_eval_string("{TextCheck}")) > 0)
	{
		lr_output_message("LibraryLogin_SC05_AddView_T01_launch is successfull");
			lr_end_transaction("LibraryLogin_SC05_AddView_T01_launch",LR_AUTO);
	}
	else
	{
		lr_error_message("LibraryLogin_SC05_AddView_T01_launch is failed for Iteration {P_Iteration},Host {P_Host}, Time {P_Time}");
		lr_end_transaction("LibraryLogin_SC05_AddView_T01_launch",LR_FAIL);
	}
	                
	lr_think_time(TT);
	


	/* launch completed */



	web_add_header("Origin", 
		"http://localhost:8082");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");


	web_reg_find("Search=Body",
		"SaveCount=TextCheck",
		"Text=Librarian Section",
		LAST);
	
	
		lr_start_transaction("LibraryLogin_SC05_AddView_T02_login");

	web_submit_data("LibrarianLogin", 
		"Action=http://{p_url}/LibrarianLogin", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://{p_url}/index.html", 
		"Snapshot=t9.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=email", "Value={p_loginid}@gmail.com", ENDITEM, 
		"Name=password", "Value={p_password}", ENDITEM, 
		LAST);

	
	web_concurrent_start(NULL);

	web_url("library1.jpg", 
		"URL=http://{p_url}/images/library1.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=http://{p_url}/LibrarianLogin", 
		"Snapshot=t10.inf", 
		LAST);

	web_url("library2.jpg", 
		"URL=http://{p_url}/images/library2.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=http://{p_url}/LibrarianLogin", 
		"Snapshot=t11.inf", 
		LAST);

	web_concurrent_end(NULL);
	
		if(atoi(lr_eval_string("{TextCheck}")) > 0)
	{
		lr_output_message("LibraryLogin_SC05_AddView_T02_login is successfull");
			lr_end_transaction("LibraryLogin_SC05_AddView_T02_login",LR_AUTO);
	}
	else
	{
		lr_error_message("LibraryLogin_SC05_AddView_T02_login is failed for Iteration {P_Iteration},Host {P_Host}, Time {P_Time}");
		lr_end_transaction("LibraryLogin_SC05_AddView_T02_login",LR_FAIL);
	}
	                
	lr_think_time(TT);
	

	web_reg_find("Search=Body",
		"SaveCount=TextCheck",
		"Text=Add Book Form",
		LAST);
	
	lr_start_transaction("LibraryLogin_SC05_AddView_T03_ClkAddBook");

	web_url("Add Book", 
		"URL=http://{p_url}/AddBookForm", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{p_url}/LibrarianLogin", 
		"Snapshot=t12.inf", 
		"Mode=HTTP", 
		LAST);
	
		if(atoi(lr_eval_string("{TextCheck}")) > 0)
	{
		lr_output_message("LibraryLogin_SC05_AddView_T03_ClkAddBook is successfull");
			lr_end_transaction("LibraryLogin_SC05_AddView_T03_ClkAddBook",LR_AUTO);
	}
	else
	{
		lr_error_message("LibraryLogin_SC05_AddView_T03_ClkAddBook is failed for Iteration {P_Iteration},Host {P_Host}, Time {P_Time}");
		lr_end_transaction("LibraryLogin_SC05_AddView_T03_ClkAddBook",LR_FAIL);
	}
	                
	lr_think_time(TT);

	web_add_header("Origin", 
		"http://localhost:8082");
	

	web_reg_find("Search=Body",
		"SaveCount=TextCheck",
		"Text=Save Book",
		LAST);
	
		lr_start_transaction("LibraryLogin_SC05_AddView_T04_ClkSavebook");

	web_submit_data("AddBook", 
		"Action=http://{p_url}/AddBook", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://{p_url}/AddBookForm", 
		"Snapshot=t14.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=callno", "Value={p_callno}", ENDITEM, 
		"Name=name", "Value={p_addname}", ENDITEM, 
		"Name=author", "Value={p_author}", ENDITEM, 
		"Name=publisher", "Value={p_publisher}", ENDITEM, 
		"Name=quantity", "Value=1", ENDITEM, 
		LAST);
		
			if(atoi(lr_eval_string("{TextCheck}")) > 0)
	{
		lr_output_message("LibraryLogin_SC05_AddView_T04_ClkSavebook is successfull");
			lr_end_transaction("LibraryLogin_SC05_AddView_T04_ClkSavebook",LR_AUTO);
	}
	else
	{
		lr_error_message("LibraryLogin_SC05_AddView_T04_ClkSavebook is failed for Iteration {P_Iteration},Host {P_Host}, Time {P_Time}");
		lr_end_transaction("LibraryLogin_SC05_AddView_T04_ClkSavebook",LR_FAIL);
	}
	                
	lr_think_time(TT);
		
	

	web_revert_auto_header("Sec-Fetch-User");

	web_revert_auto_header("Upgrade-Insecure-Requests");

	


	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");
	


	web_reg_find("Search=Body",
		"SaveCount=TextCheck",
		"Text=View Book",
		LAST);
	
		lr_start_transaction("LibraryLogin_SC05_AddView_T05_ClkViewbook");

	web_url("ViewBook", 
		"URL=http://{p_url}/ViewBook", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{p_url}/AddBook", 
		"Snapshot=t16.inf", 
		"Mode=HTTP", 
		LAST);
	
		if(atoi(lr_eval_string("{TextCheck}")) > 0)
	{
		lr_output_message("LibraryLogin_SC05_AddView_T05_ClkViewbook is successfull");
			lr_end_transaction("LibraryLogin_SC05_AddView_T05_ClkViewbook",LR_AUTO);
	}
	else
	{
		lr_error_message("LibraryLogin_SC05_AddView_T05_ClkViewbook is failed for Iteration {P_Iteration},Host {P_Host}, Time {P_Time}");
		lr_end_transaction("LibraryLogin_SC05_AddView_T05_ClkViewbook",LR_FAIL);
	}
	                
	lr_think_time(TT);


	lr_start_transaction("LibraryLogin_SC05_AddView_T06_Logout");

	web_url("Logout", 
		"URL=http://{p_url}/LogoutLibrarian", 
		"Resource=0", 
		"Referer=http://{p_url}/ViewBook", 
		"Snapshot=t17.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("LibraryLogin_SC05_AddView_T06_Logout",LR_AUTO);

	return 0;
}